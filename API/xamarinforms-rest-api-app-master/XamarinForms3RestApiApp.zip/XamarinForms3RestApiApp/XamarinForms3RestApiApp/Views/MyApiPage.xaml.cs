﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XamarinForms3RestApiApp.Views
{
    public partial class MyApiPage : ContentPage
    {
        public MyApiPage()
        {
            InitializeComponent();
        }
    }
}
