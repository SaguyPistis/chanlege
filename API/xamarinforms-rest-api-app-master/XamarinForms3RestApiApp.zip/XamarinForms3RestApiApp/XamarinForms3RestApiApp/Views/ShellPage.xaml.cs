﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XamarinForms3RestApiApp.Views
{
    public partial class ShellPage : Shell
    {
        public ShellPage()
        {
            InitializeComponent();
        }
    }
}
