﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace XamarinForms3RestApiApp.Views
{
    public partial class ApiLoc : ContentPage
    {
        public ApiLoc()
        {
            InitializeComponent();
        }
    }
}
